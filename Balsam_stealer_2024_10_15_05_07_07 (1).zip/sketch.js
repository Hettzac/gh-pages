
    function setup() {
      createCanvas(400, 400); // Create canvas 400x400
      noStroke(); // No outline for the shapes

      // Initialize pumpkin positions with random values
      for (let i = 0; i < numPumpkins; i++) {
        pumpkinX[i] = random(width); // Random X position
        pumpkinY[i] = random(height); // Random Y position
      }

      // Print the length of the array
      print("Number of pumpkins in the array: " + pumpkinX.length);
    }

    function draw() {
      background(30); // Dark background for a Halloween night

      // Draw multiple pumpkins using the array values for positions
      for (let i = 0; i < numPumpkins; i++) {
        // Draw pumpkins
        drawPumpkin(pumpkinX[i], pumpkinY[i]);

        // Move pumpkins to the right by increasing their x value
        pumpkinX[i] += random(1, 3); // Adding random motion

        // Wrap the pumpkin around the screen if it moves off
        if (pumpkinX[i] > width) {
          pumpkinX[i] = 0; // Reset X position to start from the left again
        }
      }
    }

    // Draw a simple pumpkin shape
    function drawPumpkin(x, y) {
      fill(255, 100, 0); // Orange color for the pumpkin
      ellipse(x, y, 50, 50); // Main body of the pumpkin
      fill(0); // Black for the eyes and mouth
      ellipse(x - 10, y - 10, 10, 10); // Left eye
      ellipse(x + 10, y - 10, 10, 10); // Right eye
      triangle(x - 10, y + 5, x + 10, y + 5, x, y + 15); // Mouth (spooky triangle)
    }

    // Set a pumpkin to follow the mouse when clicked
    function mousePressed() {
      pumpkinX[0] = mouseX; // Set first pumpkin's X position to mouseX
      pumpkinY[0] = mouseY; // Set first pumpkin's Y position to mouseY
    }

 
