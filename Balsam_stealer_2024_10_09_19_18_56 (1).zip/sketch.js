
    let screenColor, buttonColor1, buttonColor2, buttonColor3;
    let isScreenOn = false; 
    let bgColor; 
    let message = ""; 

    function setup() {
      createCanvas(400, 400); 
      
      // Colors
      screenColor = color(50); 
      buttonColor1 = color(100, 150, 250); 
      buttonColor2 = color(200, 100, 100); 
      buttonColor3 = color(150, 200, 100); 
      bgColor = color(245); 
    }

    function draw() {
      background(bgColor); 
      
      
      fill(100); 
      rect(100, 50, 200, 150, 20); 
      
      fill(screenColor); 
      rect(120, 70, 160, 110); 

      
      fill(100);
      rect(170, 210, 60, 20);

    
      fill(buttonColor1);
      rect(50, 300, 80, 40, 10);

      
      fill(buttonColor2);
      ellipse(320, 320, 80, 40);

      
      fill(buttonColor3);
      rect(170, 300, 60, 40, 10);

      
      fill(0);
      textSize(16);
      textAlign(CENTER);
      text(message, width / 2, 260);
    }

    
    function mousePressed() {
      
      if (mouseX > 50 && mouseX < 130 && mouseY > 300 && mouseY < 340) {
        isScreenOn = true;
        screenColor = color(100, 200, 255); 
        message = "Screen is ON";
      }
    }

    
    function mouseClicked() {
      
      if (dist(mouseX, mouseY, 320, 320) < 40) {
        isScreenOn = false;
        screenColor = color(50); 
        message = "Screen is OFF";
      }
    }

    
    function keyPressed() {
      
      if (key == 'S' && mouseX > 170 && mouseX < 230 && mouseY > 300 && mouseY < 340) {
        bgColor = color(255, 230, 200); 
        message = "Special Feature Activated!";
      }
    }

